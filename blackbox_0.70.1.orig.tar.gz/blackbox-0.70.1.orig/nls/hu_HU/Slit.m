$set 7 #Slit

$ #SlitTitle
# Slit
$ #SlitDirection
# Slit ir�ny 
$ #SlitPlacement
# Slit elhelyez�s
