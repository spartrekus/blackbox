$set 12 #Workspacemenu

$ #WorkspacesTitle
# Munkaasztalok
$ #NewWorkspace
# �j munkaasztal
$ #RemoveLast
# Utols� munkaasztal t�rl�se
