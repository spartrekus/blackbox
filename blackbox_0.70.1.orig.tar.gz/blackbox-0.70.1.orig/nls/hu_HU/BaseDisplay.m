$set 1 #BaseDisplay

$ #XError
# %s:  X hiba: %s(%d) opcodes %d/%d\n  resource 0x%lx\n
$ #SignalCaught
# %s: %d szign�lt kapott\n
$ #ShuttingDown
# Le�ll�s\n
$ #Aborting
# Programhiba... dumping core\n
$ #XConnectFail
# BaseDisplay::BaseDisplay: nem siker�lt kapcsol�dni az X szerverhez.\n
$ #CloseOnExecFail
# BaseDisplay::BaseDisplay: az �sszek�ttet�s a k�perny�vel nem 'close-on-exit'\n
$ #BadWindowRemove
# BaseDisplay::eventLoop(): helytelen ablak kiv�tele a 'Event Queue'-b�l\n
