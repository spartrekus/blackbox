$set 16 #bsetroot

$ #MustSpecify
# %s: hiba: k�telez� megadni egy kapcsol�t: -solid, -mod, -gradient\n
$ #Usage
# %s 2.0: (c) 1997-2000 Brad Hughes\n\n\
	  (c) 2001-2002 Sean 'Shaleh' Perry\n\n\
  -display <string>        haszn�land� kijelz�\n\
  -mod <x> <y>             modula minta\n\
  -foreground, -fg <color> modula el�t�r sz�ne\n\
  -background, -bg <color> modula h�tt�r sz�ne\n\n\
  -gradient <texture>      gradiens text�r�ja\n\
  -from <color>            kezd�sz�n\n\
  -to <color>              befejez�sz�n\n\n\
  -solid <color>           egyszer� h�tt�r\n\n\
  -help                    s�g�k�perny� mutat�sa �s kil�p�s\n

