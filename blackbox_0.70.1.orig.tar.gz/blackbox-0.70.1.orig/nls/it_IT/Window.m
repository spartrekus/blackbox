$set 9 #Window


$ #Creating
# BlackboxWindow::BlackboxWindow: creazione 0x%lx\n
$ #XGetWindowAttributesFail
# BlackboxWindow::BlackboxWindow: XGetWindowAttributres fallito\n
$ #CannotFindScreen
# BlackboxWindow::BlackboxWindow: impossibile trovare schermo per finestra principale 0x%lx\n
$ #Unnamed
# Senza Nome
$ #MapRequest
# BlackboxWindow::mapRequestEvent() per 0x%lx\n
$ #UnmapNotify
# BlackboxWindow::unmapNotifyEvent() per 0x%lx\n
$ #ReparentNotify
# BlackboxWindow::reparentNotifyEvent: reparent 0x%lx a 0x%lx\n
