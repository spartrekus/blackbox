$set 3 #Configmenu

$ #ConfigOptions
# Config Options
$ #FocusModel
# Focus Model
$ #WindowPlacement
# Window Placement
$ #ImageDithering
# Image Dithering
$ #OpaqueMove
# Opaque Window Moving
$ #FullMax
# Full Maximization
$ #IgnoreShaded
# Ignore Shaded Windows
$ #FocusNew
# Focus New Windows
$ #FocusLast
# Focus Window on Workspace Change
$ #DisableBindings
# Disable Bindings with Scroll Lock
$ #ClickToFocus
# Click to Focus
$ #SloppyFocus
# Sloppy Focus
$ #AutoRaise
# Auto Raise
$ #ClickRaise
# Click Raise
$ #SmartRows
# Smart Placement (Rows)
$ #SmartCols
# Smart Placement (Columns)
$ #Cascade
# Cascade Placement
$ #LeftRight
# Left to Right
$ #RightLeft
# Right to Left
$ #TopBottom
# Top to Bottom
$ #BottomTop
# Bottom to Top
$ #NoDithering
# Do not dither images
$ #OrderedDithering
# Use fast dither
$ #FloydSteinbergDithering
# Use high-quality dither
