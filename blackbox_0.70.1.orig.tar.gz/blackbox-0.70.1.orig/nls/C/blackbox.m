$set 13 #blackbox

$ #NoManagableScreens
# Blackbox::Blackbox: no managable screens found, aborting\n
$ #MapRequest
# Blackbox::process_event: MapRequest for 0x%lx\n
