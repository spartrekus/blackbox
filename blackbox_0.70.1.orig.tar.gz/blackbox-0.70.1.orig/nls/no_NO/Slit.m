$set 7 #Slit

$ #SlitTitle
# Spalte
$ #SlitDirection
# Spalte-retning
$ #SlitPlacement
# Spalte-plassering
