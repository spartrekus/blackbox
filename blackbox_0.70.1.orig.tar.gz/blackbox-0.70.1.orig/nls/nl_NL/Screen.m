$set 6 #Screen

$ #AnotherWMRunning
# BScreen::BScreen: er is een fout opgetreden bij het verbinden met de X server.\n  \
er werkt al een andere window manager op display %s.\n
$ #ManagingScreen
# BScreen::BScreen: manager op scherm %d met visual 0x%lx, kleurdiepte %d\n
$ #FontLoadFail
# BScreen::LoadStyle(): kan lettertype '%s' niet laden\n
$ #DefaultFontLoadFail
# BScreen::LoadStyle(): kan standaardlettertype niet laden\n
$ #EmptyMenuFile
# %s: leeg menu bestand\n
$ #xterm
# xterm
$ #Restart
# Herstarten
$ #Exit
# Afsluiten
$ #EXECError
# BScreen::parseMenuFile: [exec] fout, geen label en/of commando aangegeven\n
$ #EXITError
# BScreen::parseMenuFile: [exit] fout, geen label aangegeven\n
$ #STYLEError
# BScreen::parseMenuFile: [style] fout, geen label en/of bestandsnaam aangegeven\n
$ #CONFIGError
# BScreen::parseMenuFile: [config] fout, geen label aangegeven\n
$ #INCLUDEError
# BScreen::parseMenuFile: [include] fout, geen bestandsnaam aangegeven\n
$ #INCLUDEErrorReg
# BScreen::parseMenuFile: [include] fout, '%s' is geen leesbaar bestand\n
$ #SUBMENUError
# BScreen::parseMenuFile: [submenu] fout, geen label aangegeven\n
$ #RESTARTError
# BScreen::parseMenuFile: [restart] fout, geen label aangegeven\n
$ #RECONFIGError
# BScreen::parseMenuFile: [reconfig] fout, geen label aangegeven\n
$ #STYLESDIRError
# BScreen::parseMenuFile: [stylesdir/stylesmenu] fout, geen directory aangegeven\n
$ #STYLESDIRErrorNotDir
# BScreen::parseMenuFile: [stylesdir/stylesmenu] fout, '%s' is geen directory\n
$ #STYLESDIRErrorNoExist
# BScreen::parseMenuFile: [stylesdir/stylesmenu] fout, '%s' bestaat niet\n
$ #WORKSPACESError
# BScreen::parseMenuFile: [workspaces] fout, geen label aangegeven\n
$ #PositionLength
# 0: 0000 x 0: 0000
$ #PositionFormat
# X: %4d x Y: %4d
$ #GeometryFormat
# B: %4d x H: %4d

