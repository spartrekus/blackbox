$set 3 #Configmenu

$ #ConfigOptions
# Instellingen
$ #FocusModel
# Focus van vensters
$ #WindowPlacement
# Plaatsing van vensters
$ #ImageDithering
# Kleurbenadering
$ #OpaqueMove
# Vensters slepen met inhoud
$ #FullMax
# Volledig maximaliseren
$ #FocusNew
# Focus nieuwe vensters
$ #FocusLast
# Focus venster bij werkblad wissel
$ #DisableBindings
# Scroll Lock schakelt bindingen uit
$ #ClickToFocus
# Focus met muisklik
$ #SloppyFocus
# Focus volgt muispijl
$ #AutoRaise
# Automatisch naar voorgrond
$ #ClickRaise
# Naar voorgrond met muisklik
$ #SmartRows
# Optimale plaatsing (rijen)
$ #SmartCols
# Optimale plaatsing (kolommen)
$ #Cascade
# Trapsgewijs
$ #LeftRight
# Van links naar rechts
$ #RightLeft
# Van rechts naar links
$ #TopBottom
# Van boven naar beneden
$ #BottomTop
# Van beneden naar boven
$ #NoDithering
# Do not dither images
$ #OrderedDithering
# Use fast dither
$ #FloydSteinbergDithering
# Use high-quality dither
