$set 1 #BaseDisplay

$ #XError
# %s:  X fout: %s(%d) opcodes %d/%d\n  resource 0x%lx\n
$ #SignalCaught
# %s: signaal %d gekregen\n
$ #ShuttingDown
# bezig af te sluiten\n
$ #Aborting
# afgebroken... core bestand gedumpt\n
$ #XConnectFail
# BaseDisplay::BaseDisplay: verbinding met X server mislukt\n
$ #CloseOnExecFail
# BaseDisplay::BaseDisplay: kan display verbinding niet markeren als 'close-on-exec'\n
$ #BadWindowRemove
# BaseDisplay::eventLoop(): verwijder 'bad window' van gebeurtenis wachtrij\n
