$set 3 #Configmenu

$ #ConfigOptions
# Konfiguratsioon
$ #FocusModel
# Fookusmood
$ #WindowPlacement
# Akende paigutamine
$ #ImageDithering
# Piltide teravustamine
$ #OpaqueMove
# N�htav akende liigutamine
$ #FullMax
# �le-ekraani suurendus
$ #FocusNew
# Fookus uutele akendele
$ #FocusLast
# Fokusseeri viimane aken
$ #ClickToFocus
# Klikka fookuse saamiseks
$ #SloppyFocus
# Kaasask�iv fookus
$ #AutoRaise
# Akende esiletoomine
$ #SmartRows
# Arukas paigutus (read)
$ #SmartCols
# Arukas paigutus (tulbad)
$ #Cascade
# Kaskaadis
$ #LeftRight
# Vasakult paremale
$ #RightLeft
# Paremalt vasakule
$ #TopBottom
# �levalt alla
$ #BottomTop
# Alt �lesse
$ #NoDithering
# Do not dither images
$ #OrderedDithering
# Use fast dither
$ #FloydSteinbergDithering
# Use high-quality dither
