$set 15 #Common

$ #Yes
# Jah
$ #No
# Ei

$ #DirectionTitle
# Suund
$ #DirectionHoriz
# Horisontaalne
$ #DirectionVert
# Vertikaalne

$ #AlwaysOnTop
# Alati esiplaanil

$ #PlacementTitle
# Asetus
$ #PlacementTopLeft
# �leval vasakul
$ #PlacementCenterLeft
# Keskel vasakul
$ #PlacementBottomLeft
# All vasakul
$ #PlacementTopCenter
# �leval keskel
$ #PlacementBottomCenter
# All keskel
$ #PlacementTopRight
# �leval paremal
$ #PlacementCenterRight
# Keskel paremal
$ #PlacementBottomRight
# All paremal
