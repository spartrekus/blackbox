$set 1 #BaseDisplay

$ #XError
# %s:  X'i viga: %s(%d) opkood %d/%d\n  resurss 0x%lx\n
$ #SignalCaught
# %s: signaal %d p��tud\n
$ #ShuttingDown
# l�petame\n
$ #Aborting
# katkestame... m�lupilt tehtud\n
$ #XConnectFail
# BaseDisplay::BaseDisplay: �henduse saamine X serveriga eba�nnestus.\n
$ #CloseOnExecFail
# BaseDisplay::BaseDisplay: �henduse m�rgistamine 'close-on-exec' eba�nnestus\n
$ #BadWindowRemove
# BaseDisplay::eventLoop(): eemaldame vigase akna tominigute reast\n
