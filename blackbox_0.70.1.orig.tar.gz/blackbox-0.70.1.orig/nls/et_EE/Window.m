$set 9 #Window


$ #Creating
# BlackboxWindow::BlackboxWindow: loome 0x%lx\n
$ #XGetWindowAttributesFail
# BlackboxWindow::BlackboxWindow: XGetWindowAttributres eba�nnestus\n
$ #CannotFindScreen
# BlackboxWindow::BlackboxWindow: ei leidnud displeid juuraknale 0x%lx\n
$ #Unnamed
# Nimeta
$ #MapRequest
# BlackboxWindow::mapRequestEvent() 0x%lx'le\n
$ #UnmapNotify
# BlackboxWindow::unmapNotifyEvent() 0x%lx'le\n
$ #ReparentNotify
# BlackboxWindow::reparentNotifyEvent: 0x%lx juurele 0x%lx\n
