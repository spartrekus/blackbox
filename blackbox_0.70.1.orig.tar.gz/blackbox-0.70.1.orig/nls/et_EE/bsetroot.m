$set 16 #bsetroot

$ #MustSpecify
# %s: viga: pead m��ratlema �he j�rgnevaist: -solid, -mod, -gradient\n
$ #Usage
# %s 2.0: (c) 1997-2000 Brad Hughes\n\n\
	  (c) 2001-2002 Sean 'Shaleh' Perry\n\n\
  -display <string>        displei �hendus\n\
  -mod <x> <y>             moodula tapeet\n\
  -foreground, -fg <color> esiplaani v�rvi moodula\n\
  -background, -bg <color> tausta v�rvi moodula\n\n\
  -gradient <texture>      gradientne tekstuur\n\
  -from <color>            gradiendi algusv�rv\n\
  -to <color>              gradiendi l�puv�rv\n\n\
  -solid <color>           �htne v�rv\n\n\
  -help                    n�ida seda abiteksti ja v�lju\n

