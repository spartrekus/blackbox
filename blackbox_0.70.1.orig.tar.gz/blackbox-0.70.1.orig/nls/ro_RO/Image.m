$set 5 #Image

$ #ErrorCreatingSolidPixmap
# BImage::render_solid: eroare de creare imagine\n
$ #ErrorCreatingXImage
# BImage::renderXImage: eroare de creare XImage\n
$ #UnsupVisual
# BImage::renderXImage: mod vizual incompatibil\n
$ #ErrorCreatingPixmap
# BImage::renderPixmap: eroare de creare imagine\n
$ #InvalidColormapSize
# BImageControl::BImageControl: harta culorilor are marimea incorecta %d (%d/%d/%d) - reducere automata\n
$ #ErrorAllocatingColormap
# BImageControl::BImageControl: eroare de alocare a hartii culorilor\n
$ #ColorAllocFail
# BImageControl::BImageControl: nu am putut aloca culoarea %d/%d/%d\n
$ #PixmapRelease
# BImageControl::~BImageControl: memorie intermediara imagini - eliberare spatiu pentru %d imagini\n
$ #PixmapCacheLarge
# BImageControl::renderImage: memoria intermediara e prea mare, reducere fortata\n
$ #ColorParseError
# BImageControl::getColor: eroare de procesare a culorii: '%s'\n
$ #ColorAllocError
# BImageControl::getColor: eroare de alocare a culorii: '%s'\n
