$set 12 #Workspacemenu

$ #WorkspacesTitle
# Zone de lucru
$ #NewWorkspace
# Zona noua de lucru
$ #RemoveLast
# Sterge ultima zona
