$set 6 #Screen

$ #AnotherWMRunning
# BScreen::BScreen: a aparut o eroare in cursul interogarii serverului X.\n  \
Exista deja un manager de ferestre pe ecranul %s.\n
$ #ManagingScreen
# BScreen::BScreen: administrez ecranul %d folosind modul vizual 0x%lx, adincime %d\n
$ #FontLoadFail
# BScreen::LoadStyle(): nu am putut incarca fontul '%s'\n
$ #DefaultFontLoadFail
# BScreen::LoadStyle(): nu am putut incarca fontul implicit.\n
$ #EmptyMenuFile
# %s: fisierul de configurare a meniului nu contine nimic\n
$ #xterm
# xterm
$ #Restart
# Repornire
$ #Exit
# Iesire
$ #EXECError
# BScreen::parseMenuFile: [exec] eroare, nu s-a completat eticheta si/sau comanda asociata\n
$ #EXITError
# BScreen::parseMenuFile: [exit] eroare, nu s-a completat eticheta\n
$ #STYLEError
# BScreen::parseMenuFile: [style] eroare, nu s-a completat eticheta si/sau comanda asociata\n
$ #CONFIGError
# BScreen::parseMenuFile: [config] eroare, nu s-a completat eticheta\n
$ #INCLUDEError
# BScreen::parseMenuFile: [include] eroare, nu s-a precizat nici un nume de fisier\n
$ #INCLUDEErrorReg
# BScreen::parseMenuFile: [include] eroare, '%s' nu este un fisier obisnuit\n
$ #SUBMENUError
# BScreen::parseMenuFile: [submenu] eroare, nu s-a completat eticheta\n
$ #RESTARTError
# BScreen::parseMenuFile: [restart] eroare, nu s-a completat eticheta\n
$ #RECONFIGError
# BScreen::parseMenuFile: [reconfig] eroare, nu s-a completat eticheta\n
$ #STYLESDIRError
# BScreen::parseMenuFile: [stylesdir/stylesmenu] eroare, nu s-a precizat nici un director\n
$ #STYLESDIRErrorNotDir
# BScreen::parseMenuFile: [stylesdir/stylesmenu] error, '%s' nu este un director\n
$ #STYLESDIRErrorNoExist
# BScreen::parseMenuFile: [stylesdir/stylesmenu] error, '%s' nu exista\n
$ #WORKSPACESError
# BScreen::parseMenuFile: [workspaces] eroare, nu s-a completat eticheta\n
$ #PositionLength
# 0: 0000 x 0: 0000
$ #PositionFormat
# X: %4d x Y: %4d
$ #GeometryFormat
# W: %4d x H: %4d

