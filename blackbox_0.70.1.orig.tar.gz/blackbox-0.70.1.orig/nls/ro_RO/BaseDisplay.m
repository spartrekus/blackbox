$set 1 #BaseDisplay

$ #XError
# %s:  eroare de X: %s(%d) opcode %d/%d\n  resursa 0x%lx\n
$ #SignalCaught
# %s: am primit semnalul %d\n
$ #ShuttingDown
# terminare normala\n
$ #Aborting
# terminare fortata... am scris fisierul core\n
$ #XConnectFail
# BaseDisplay::BaseDisplay: conexiunea la serverul X a esuat.\n
$ #CloseOnExecFail
# BaseDisplay::BaseDisplay: nu am putut pune marcajul close-on-exec pe conexiunea la ecran\n
$ #BadWindowRemove
# BaseDisplay::eventLoop(): sterg fereastra gresita din coada de evenimente\n
