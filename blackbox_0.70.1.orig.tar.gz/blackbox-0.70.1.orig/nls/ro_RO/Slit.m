$set 7 #Slit

$ #SlitTitle
# Fanta de incarcare
$ #SlitDirection
# Orientarea fantei
$ #SlitPlacement
# Pozitia fantei
