$set 5 #Image

$ #ErrorCreatingSolidPixmap
# BImage::render_solid: fel under skapande av pixmap\n
$ #ErrorCreatingXImage
# BImage::renderXImage: fel under skapande av XImage\n
$ #UnsupVisual
# BImage::renderXImage: ej st�d f�r f�rgdjup\n
$ #ErrorCreatingPixmap
# BImage::renderPixmap: fel under skapande av pixmap\n
$ #InvalidColormapSize
# BImageControl::BImageControl: ogiltig f�rgkarta storlek %d (%d/%d/%d) - reducerar\n
$ #ErrorAllocatingColormap
# BImageControl::BImageControl: fel under allokering av f�rgkarta\n
$ #ColorAllocFail
# BImageControl::BImageControl: misslyckades att allokera f�rg %d/%d/%d\n
$ #PixmapRelease
# BImageControl::~BImageControl: pixmap cache - sl�pper %d pixmappar\n
$ #PixmapCacheLarge
# BImageControl::renderImage: stor cache, tvingar upprensning\n
$ #ColorParseError
# BImageControl::getColor: f�rgfel: '%s'\n
$ #ColorAllocError
# BImageControl::getColor: f�rgallokeringsfel: '%s'\n
