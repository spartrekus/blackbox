$set 13 #blackbox

$ #NoManagableScreens
# Blackbox::Blackbox: inga hanterbara sk�rmar hittades, avslutar\n
$ #MapRequest
# Blackbox::process_event: MapRequest f�r 0x%lx\n
