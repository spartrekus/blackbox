$set 3 #Configmenu

$ #ConfigOptions
# Inst�llningar
$ #FocusModel
# Fokusmodell
$ #WindowPlacement
# F�nsterplacering
$ #ImageDithering
# Bilddithering
$ #OpaqueMove
# Ogenomskinlig f�nsterf�rflyttning
$ #FullMax
# Full maximering
$ #FocusNew
# Fokus p� nya f�nster
$ #FocusLast
# Fokusera f�nster vid skrivbordsbyte
$ #DisableBindings
# G�r s� att bindningar inte fungerar med Scroll Lock
$ #ClickToFocus
# Klicka f�r fokus
$ #SloppyFocus
# Hafsig fokus
$ #AutoRaise
# H�j automatiskt
$ #ClickRaise
# Klicka f�r att h�ja
$ #SmartRows
# Smart placering (Rader)
$ #SmartCols
# Smart placering (Kolumner)
$ #Cascade
# Kaskadplacering
$ #LeftRight
# Fr�n v�nster
$ #RightLeft
# Fr�n h�ger
$ #TopBottom
# Uppifr�n
$ #BottomTop
# Nerifr�n
$ #NoDithering
# Do not dither images
$ #OrderedDithering
# Use fast dither
$ #FloydSteinbergDithering
# Use high-quality dither
