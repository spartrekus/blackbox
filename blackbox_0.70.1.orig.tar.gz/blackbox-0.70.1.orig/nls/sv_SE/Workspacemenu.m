$set 12 #Workspacemenu

$ #WorkspacesTitle
# Skrivbord
$ #NewWorkspace
# Nytt skrivbord
$ #RemoveLast
# Ta bort sista
