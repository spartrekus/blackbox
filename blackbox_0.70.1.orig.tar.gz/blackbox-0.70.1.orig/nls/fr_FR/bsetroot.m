$set 16 #bsetroot

$ #MustSpecify
# %s: Erreur: il faut pr�ciser : -solid, -mod, -gradient\n
$ #Usage
# %s 2.0: (c) 1997-2000 Brad Hughes\n\n\
	  (c) 2001-2002 Sean 'Shaleh' Perry\n\n\
  -display <cha�ne>        	connexion � l'affichage\n\
  -mod <x> <y>             	motif\n\
  -foreground, -fg <couleur> 	couleur d'avant plan\n\
  -background, -bg <couleur> 	couleur d'arri�re plan\n\n\
  -gradient <texture>      	texture du d�grad�\n\
  -from <couleur>            	couleur de d�part du d�grad�\n\
  -to <couleur>              	couleur d'arriv�e du d�grad�\n\n\
  -solid <couleur>           	couleur uniforme\n\n\
  -help                    	affiche ce texte d'aide et quitte\n

