$set 5 #Image

$ #ErrorCreatingSolidPixmap
# BImage::render_solid: Erreur de cr�ation de pixmap\n
$ #ErrorCreatingXImage
# BImage::renderXImage: Erreur de cr�ation de XImage\n
$ #UnsupVisual
# BImage::renderXImage: Mode visuel non support�\n
$ #ErrorCreatingPixmap
# BImage::renderPixmap: Erreur de cr�ation de pixmap\n
$ #InvalidColormapSize
# BImageControl::BImageControl: Taille de la palette de couleurs invalide%d (%d/%d/%d) - coupe\n
$ #ErrorAllocatingColormap
# BImageControl::BImageControl: Erreur d'allocation de la palette de couleurs\n
$ #ColorAllocFail
# BImageControl::BImageControl: Echec d'allocation de couleur %d/%d/%d\n
$ #PixmapRelease
# BImageControl::~BImageControl: Cache pixmap - abandon %d pixmaps\n
$ #PixmapCacheLarge
# BImageControl::renderImage: Occupation du cache importante, nettoyage forc�\n
$ #ColorParseError
# BImageControl::getColor: Erreur de lecture de couleur: '%s'\n
$ #ColorAllocError
# BImageControl::getColor: Erreur d'allocation,couleur: '%s'\n
