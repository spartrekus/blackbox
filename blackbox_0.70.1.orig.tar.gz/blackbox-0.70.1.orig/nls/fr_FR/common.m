$set 15 #Common

$ #Yes
# Oui
$ #No
# Non

$ #DirectionTitle
# Orientation
$ #DirectionHoriz
# Horizontal
$ #DirectionVert
# Vertical

$ #AlwaysOnTop
# Toujours au dessus

$ #PlacementTitle
# Disposition
$ #PlacementTopLeft
# En haut � gauche
$ #PlacementCenterLeft
# Au centre � gauche
$ #PlacementBottomLeft
# En bas � gauche
$ #PlacementTopCenter
# En haut au centre
$ #PlacementBottomCenter
# En bas au centre
$ #PlacementTopRight
# En haut � droite
$ #PlacementCenterRight
# Au centre � droite
$ #PlacementBottomRight
# En bas � droite

$ #AutoHide
# Auto dispara�t
