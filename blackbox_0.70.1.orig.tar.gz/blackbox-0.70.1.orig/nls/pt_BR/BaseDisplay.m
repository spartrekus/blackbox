$set 1 #BaseDisplay

$ #XError
# %s:  X erro: %s(%d) opcodes %d/%d\n  recurso 0x%lx\n
$ #SignalCaught
# %s: sinal recebido %d\n
$ #ShuttingDown
# finalizando\n
$ #Aborting
# abortando... descarregando mem�ria\n
$ #XConnectFail
# BaseDisplay::BaseDisplay: conec��o ao servidor X falhou.\n
$ #CloseOnExecFail
# BaseDisplay::BaseDisplay: imposs�vel exibir sinal de conex�o como fechar-em-execu��o\n
$ #BadWindowRemove
# BaseDisplay::eventLoop(): removendo janela inv�lida da lista de eventos\n
