$set 3 #Configmenu

$ #ConfigOptions
# Konfiguracja
$ #FocusModel
# Spos�b aktywacji okien 
$ #WindowPlacement
# Rozmieszczanie okien
$ #ImageDithering
# Rastrowanie obrazu
$ #OpaqueMove
# Wy�wietlaj zawarto�� przesuwanego okna
$ #FullMax
# Pe�noekranowa maksymalizacja
$ #FocusNew
# Ustawiaj nowe okna jako aktywne
$ #FocusLast
# Zmie� aktywne okno przy zmianie pulpit�w
$ #DisableBindings
# Scroll Lock blokuje modyfikatory
$ #ClickToFocus
# Uaktywnia klikni�cie
$ #SloppyFocus
# Uaktywnia kursor
$ #AutoRaise
# Podnoszenie automatyczne
$ #ClickRaise
# Podnoszenie po klikni�ciu
$ #SmartRows
# Optymalne (Wiersze)
$ #SmartCols
# Optymalne (Kolumny)
$ #Cascade
# Kaskada
$ #LeftRight
# od Lewej do Prawej
$ #RightLeft
# od Prawej do Lewej
$ #TopBottom
# z G�ry na D�
$ #BottomTop
# z Do�u do G�ry
$ #NoDithering
# Do not dither images
$ #OrderedDithering
# Use fast dither
$ #FloydSteinbergDithering
# Use high-quality dither
