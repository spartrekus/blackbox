$set 12 #Workspacemenu

$ #WorkspacesTitle
# Pulpit 
$ #NewWorkspace
# Nowy pulpit
$ #RemoveLast
# Usu� ostatni
