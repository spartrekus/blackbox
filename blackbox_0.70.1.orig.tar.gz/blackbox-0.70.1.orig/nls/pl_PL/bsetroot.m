$set 16 #bsetroot

$ #MustSpecify
# %s: b��d: nale�y u�y� jednej z opcji: -solid, -mod, -gradient\n
$ #Usage
# %s 2.0: (c) 1997-2000 Brad Hughes\n\n\
	  (c) 2001-2002 Sean 'Shaleh' Perry\n\n\
  -display <string>        po��cz z podanym panelem graficznym\n\
  -mod <x> <y>             wsp�czynniki siatki typu modula\n\
  -foreground, -fg <color> kolor siatki\n\
  -background, -bg <color> kolor t�a siatki\n\n\
  -gradient <texture>      tekstura gradientowa\n\
  -from <color>            pocz�tkowy kolor gradientu\n\
  -to <color>              ko�cowy kolor gradientu\n\n\
  -solid <color>           jednolite wype�nienie podanym kolorem\n\n\
  -help                    wy�wietla ten komunikat\n

