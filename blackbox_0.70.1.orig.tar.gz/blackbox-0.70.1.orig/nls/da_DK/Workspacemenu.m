$set 12 #Workspacemenu

$ #WorkspacesTitle
# Skriveborde
$ #NewWorkspace
# Nyt skrivebord
$ #RemoveLast
# Fjern sidste
