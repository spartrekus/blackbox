$set 9 #Window


$ #Creating
# BlackboxWindow::BlackboxWindow: skaber 0x%lx\n
$ #XGetWindowAttributesFail
# BlackboxWindow::BlackboxWindow: XGetWindowAttributres fejlede\n
$ #CannotFindScreen
# BlackboxWindow::BlackboxWindow: kunne ikke finde sk�rm til hovedvinduet 0x%lx\n
$ #Unnamed
# Intet navn
$ #MapRequest
# BlackboxWindow::mapRequestEvent() for 0x%lx\n
$ #UnmapNotify
# BlackboxWindow::unmapNotifyEvent() for 0x%lx\n
$ #ReparentNotify
# BlackboxWindow::reparentNotifyEvent: s�tter 0x%lx til 0x%lx\n
