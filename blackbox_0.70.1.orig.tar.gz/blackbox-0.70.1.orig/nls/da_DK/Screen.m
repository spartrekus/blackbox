$set 6 #Screen

$ #AnotherWMRunning
# BScreen::BScreen: fejl ved foresp�rgsel til X server.\n  \
en anden window manager er allerede k�rende p� display %s.\n
$ #ManagingScreen
# BScreen::BScreen: h�ndterer sk�rm %d med visuel 0x%lx, farvedybde %d\n
$ #FontLoadFail
# BScreen::LoadStyle(): kunne ikke hente font '%s'\n
$ #DefaultFontLoadFail
# BScreen::LoadStyle(): kunne ikke hente standardfonten.\n
$ #EmptyMenuFile
# %s: tom menu fil\n
$ #xterm
# xterm
$ #Restart
# Genstart
$ #Exit
# Afslut
$ #EXECError
# BScreen::parseMenuFile: [exec] fejl, ingen menu etikette og/eller kommando defineret\n
$ #EXITError
# BScreen::parseMenuFile: [exit] fejl, ingen menu etikette defineret\n
$ #STYLEError
# BScreen::parseMenuFile: [style] fejl, ingen menu etikette og/eller filnavn \
defineret\n
$ #CONFIGError
# BScreen::parseMenuFile: [config] fejl, ingen menu etikette defineret\n
$ #INCLUDEError
# BScreen::parseMenuFile: [include] fejl, intet filnavn defineret\n
$ #INCLUDEErrorReg
# BScreen::parseMenuFile: [include] fejl, '%s' er ikke en normal fil\n
$ #SUBMENUError
# BScreen::parseMenuFile: [submenu] fejl, ingen menu etikette defineret\n
$ #RESTARTError
# BScreen::parseMenuFile: [restart] fejl, ingen menu etikette defineret\n
$ #RECONFIGError
# BScreen::parseMenuFile: [reconfig] fejl, ingen menu etikette defineret\n
$ #STYLESDIRError
# BScreen::parseMenuFile: [stylesdir/stylesmenu] fejl, intet katalog defineret\n
$ #STYLESDIRErrorNotDir
# BScreen::parseMenuFile: [stylesdir/stylesmenu] fejl, '%s' er ikke et katalog\n
$ #STYLESDIRErrorNoExist
# BScreen::parseMenuFile: [stylesdir/stylesmenu] fejl, '%s' eksisterer ikke\n
$ #WORKSPACESError
# BScreen::parseMenuFile: [workspaces] fejl, ingen menu etikette defineret\n
$ #PositionLength
# 0: 0000 x 0: 0000
$ #PositionFormat
# X: %4d x Y: %4d
$ #GeometryFormat
# W: %4d x H: %4d

