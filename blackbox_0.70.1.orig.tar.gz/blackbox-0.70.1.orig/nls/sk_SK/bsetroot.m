$set 16 #bsetroot

$ #MustSpecify
# %s: chyba: mus�te �pecifikova� jeden z parametrov: -solid, -mod, -gradient\n
$ #Usage
# %s 2.0: (c) 1997-2000 Brad Hughes\n\n\
	  (c) 2001-2002 Sean 'Shaleh' Perry\n\n\
  -display <string>        pripojenie k obrazovke\n\
  -mod <x> <y>             modul vzorky\n\
  -foreground, -fg <color> modul farby popredia\n\
  -background, -bg <color> modul farby pozadia\n\n\
  -gradient <texture>      text�ra farebn�ho prechodu\n\
  -from <color>            po�iato�n� farba vo farebnom prechode\n\
  -to <color>              kone�n� farba vo farebnom prechode\n\n\
  -solid <color>           jednoliata farba\n\n\
  -help                    vyp��e t�to n�povedu a skon��\n

