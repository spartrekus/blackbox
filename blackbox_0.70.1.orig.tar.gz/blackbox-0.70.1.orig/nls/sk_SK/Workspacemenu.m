$set 12 #Workspacemenu

$ #WorkspacesTitle
# Pracovn� plochy
$ #NewWorkspace
# Nov� pracovn� plocha
$ #RemoveLast
# Odstr�ni� posledn�
