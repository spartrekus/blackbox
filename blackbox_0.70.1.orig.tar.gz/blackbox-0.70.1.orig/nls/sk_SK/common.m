$set 15 #Common

$ #Yes
# �no
$ #No
# Nie

$ #DirectionTitle
# Smer
$ #DirectionHoriz
# Horizont�lny
$ #DirectionVert
# Vertik�lny

$ #AlwaysOnTop
# St�le na vrchu

$ #PlacementTitle
# Umiestnenie
$ #PlacementTopLeft
# V�avo hore
$ #PlacementCenterLeft
# Uprostred v�avo
$ #PlacementBottomLeft
# V�avo dole
$ #PlacementTopCenter
# Hore uprostred
$ #PlacementBottomCenter
# Dole uprostred
$ #PlacementTopRight
# Vpravo hore
$ #PlacementCenterRight
# Uprostred vpravo
$ #PlacementBottomRight
# Vpravo dole

$ #AutoHide
# Automaticky skry�
