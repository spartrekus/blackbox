$set 10 #Windowmenu

$ #SendTo
# Umiestni� na ...
$ #Shade
# Zrolova�
$ #Iconify
# Zmeni� na ikonu
$ #Maximize
# Maximalizova�
$ #Raise
# Presun�� do popredia
$ #Lower
# Presun�� do pozadia
$ #Stick
# Prilepi�
$ #KillClient
# Ukon�i� klienta
$ #Close
# Zavrie�
