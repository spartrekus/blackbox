$set 16 #bsetroot

$ #MustSpecify
# %s : hata : -solid, -mod yada -gradient'den birisini belirlemek zorundas�n\n
$ #Usage
# %s 2.0 : Tel'if hakk� (c) 1997-2000 Brad Hughes\n\n\
	  (c) 2001-2002 Sean 'Shaleh' Perry\n\n\
  -display <metin>         ekran belirlemesi\n\
  -mod <x> <y>             b�l���m i�lemi\n\
  -foreground, -fg <renk>  b�l���m �nalan�\n\
  -background, -bg <renk>  b�l���m ardalan�\n\n\
  -gradient <kaplam>       ge�i�im kaplam�\n\
  -from <renk>             ge�i�im ba�lama rengi\n\
  -to <renk>               ge�i�im biti� rengi\n\n\
  -solid <renk>            tek renk\n\n\
  -help                    bu yard�m iletisini g�ster ve ��k\n

