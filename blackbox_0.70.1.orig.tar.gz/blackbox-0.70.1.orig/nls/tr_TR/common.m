$set 15 #Common

$ #Yes
# Evet
$ #No
# Hay�r

$ #DirectionTitle
# Y�n
$ #DirectionHoriz
# Ufki
$ #DirectionVert
# Dikey

$ #AlwaysOnTop
# Her zaman �stte

$ #PlacementTitle
# Yerle�im
$ #PlacementTopLeft
# Sol �st
$ #PlacementCenterLeft
# Sol orta 
$ #PlacementBottomLeft
# Sol alt
$ #PlacementTopCenter
# �st orta
$ #PlacementBottomCenter
# Alt orta
$ #PlacementTopRight
# Sa� �st
$ #PlacementCenterRight
# Sa� orta
$ #PlacementBottomRight
# Sa� �st
