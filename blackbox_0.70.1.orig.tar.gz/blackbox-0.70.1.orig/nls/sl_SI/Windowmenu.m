$set 10 #Windowmenu

$ #SendTo
# Na delovno povr�ino...
$ #Shade
# Zastri
$ #Iconify
# Pomanj�aj
$ #Maximize
# Pove�aj
$ #Raise
# Prika�i
$ #Lower
# Zakrij
$ #Stick
# Prilepi
$ #KillClient
# Zaustavi 
$ #Close
# Zapusti
