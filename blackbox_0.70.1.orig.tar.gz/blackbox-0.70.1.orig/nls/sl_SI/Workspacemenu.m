$set 12 #Workspacemenu

$ #WorkspacesTitle
# Delovne povr�ine
$ #NewWorkspace
# Nova delovna povr�ina
$ #RemoveLast
# Odstrani zadnjo 
