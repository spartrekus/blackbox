$set 5 #Image

$ #ErrorCreatingSolidPixmap
# BImage::render_solid: napaka pri izdelavi slike (pixmap)\n
$ #ErrorCreatingXImage
# BImage::renderXImage: napaka pri izdelavi slike (XImage)\n
$ #UnsupVisual
# BImage::renderXImage: nepodprt videz\n
$ #ErrorCreatingPixmap
# BImage::renderPixmap: napaka pri izdelavi slike (pixmap)\n
$ #InvalidColormapSize
# BImageControl::BImageControl: prevelika barvna paleta %d (%d/%d/%d) - kr�im\n
$ #ErrorAllocatingColormap
# BImageControl::BImageControl: napaka pri dodeljevanju palete\n
$ #ColorAllocFail
# BImageControl::BImageControl: napaka pri dodeljevanju barve %d/%d/%d\n
$ #PixmapRelease
# BImageControl::~BImageControl: medpomnilnik slik - zavr�enih je %d slik\n
$ #PixmapCacheLarge
# BImageControl::renderImage: medpomnilnik je zrasel, prisilno �i��enje\n
$ #ColorParseError
# BImageControl::getColor: napaka pri branju barve: '%s'\n
$ #ColorAllocError
# BImageControl::getColor: napaka pri dodeljevanju barve: '%s'\n

