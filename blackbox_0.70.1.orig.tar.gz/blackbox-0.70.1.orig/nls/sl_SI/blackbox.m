$set 13 #blackbox

$ #NoManagableScreens
# Blackbox::Blackbox: ni mo� najti upravljivih zaslonov, prekinitev\n
$ #MapRequest
# Blackbox::process_event: MapRequest za 0x%lx\n
