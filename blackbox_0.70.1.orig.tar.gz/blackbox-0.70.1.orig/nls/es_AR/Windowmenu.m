$set 10 #Windowmenu

$ #SendTo
# Enviar A ...
$ #Shade
# Enrollar
$ #Iconify
# Iconizar
$ #Maximize
# Maximizar
$ #Raise
# Elevar
$ #Lower
# Bajar
$ #Stick
# Fijar
$ #KillClient
# Matar Cliente
$ #Close
# Cerrar
