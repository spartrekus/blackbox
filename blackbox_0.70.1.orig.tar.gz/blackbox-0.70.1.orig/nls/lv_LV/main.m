$set 14 #main

$ #RCRequiresArg
# k��da: '-rc' nepiecie�ams arguments\n
$ #DISPLAYRequiresArg
# k��da: '-display' nepiecie�ams arguments\n
$ #WarnDisplaySet
# br�din�jums: nevar�ju iestat�t vides main�go 'DISPLAY'\n
$ #Usage
# Blackbox %s : (c) 2001 - 2002 Sean 'Shaleh' Perry\n\
  \t\t\t 1997 - 2000, 2002 Brad Hughes\n\n\
  -display <virkne>\t\tlietot displeja savienojumu.\n\
  -rc <virkne>\t\t\tlietot citu resersu failu.\n\
  -version\t\t\tpar�d�t versiju un iziet.\n\
  -help\t\t\t\tpar�d�t �o pal�dz�bas tekstu un iziet.\n\n
$ #CompileOptions
# Kompil�cijas laika opcijas:\n\
  Atk��do�ana\t\t\t%s\n\
  Veidne:\t\t\t%s\n\
  8bpp Pak�pes Ton��ana:\t%s\n\n
