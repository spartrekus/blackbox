$set 12 #Workspacemenu

$ #WorkspacesTitle
# Darba vietas
$ #NewWorkspace
# Jauna Darba vieta
$ #RemoveLast
# No�emt P�d�jo
