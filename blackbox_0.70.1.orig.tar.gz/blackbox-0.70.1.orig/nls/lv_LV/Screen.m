$set 6 #Screen

$ #AnotherWMRunning
# BScreen::BScreen: atgad�j�s k��da izvaic�jot X-serveri.\n  \
jau darbojas cits logu p�rvaldnieks uz displeja %s.\n
$ #ManagingScreen
# BScreen::BScreen: parvaldu ekr�nu %d, lietojot vizu�lo 0x%lx, dzi�ums %d\n
$ #FontLoadFail
# BScreen::LoadStyle(): nevar�ju iel�d�t fontu '%s'\n
$ #DefaultFontLoadFail
# BScreen::LoadStyle(): nevar�ju iel�d�t noklus�to fontu.\n
$ #EmptyMenuFile
# %s: tuk�s izv�lnes fails\n
$ #xterm
# xterm
$ #Restart
# Restart�t
$ #Exit
# Iziet
$ #EXECError
# BScreen::parseMenuFile: [exec] k��da, nav defin�ta izv�lnes iez�me un/vai komanda\n
$ #EXITError
# BScreen::parseMenuFile: [exit] k��da, nav defin�ta izv�lnes iez�me\n
$ #STYLEError
# BScreen::parseMenuFile: [style] k��da, nav defin�ta izv�lnes iez�me un/vai \
faila nosaukums\n
$ #CONFIGError
# BScreen::parseMenuFile: [config] k��da, nav defin�ta izv�lnes iez�me\n
$ #INCLUDEError
# BScreen::parseMenuFile: [include] k��da, nav defin�ts faila nosaukums\n
$ #INCLUDEErrorReg
# BScreen::parseMenuFile: [include] k��da, '%s' nav parasts fails\n
$ #SUBMENUError
# BScreen::parseMenuFile: [submenu] k��da, nav defin�ta izv�lnes iez�me\n
$ #RESTARTError
# BScreen::parseMenuFile: [restart] k��da, nav defin�ta izv�lnes iez�me\n
$ #RECONFIGError
# BScreen::parseMenuFile: [reconfig] k��da, nav defin�ta izv�lnes iez�me\n
$ #STYLESDIRError
# BScreen::parseMenuFile: [stylesdir/stylesmenu] k��da, nav defin�ta direktorija\n
$ #STYLESDIRErrorNotDir
# BScreen::parseMenuFile: [stylesdir/stylesmenu] k��da, '%s' nav \
direktorija\n
$ #STYLESDIRErrorNoExist
# BScreen::parseMenuFile: [stylesdir/stylesmenu] k��da, '%s' neeksist�\n
$ #WORKSPACESError
# BScreen::parseMenuFile: [workspaces] k��da, nav defin�ta izv�lnes iez�me\n
$ #PositionLength
# 0: 0000 x 0: 0000
$ #PositionFormat
# X: %4d x Y: %4d
$ #GeometryFormat
# P: %4d x A: %4d

