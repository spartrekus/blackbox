$set 16 #bsetroot

$ #MustSpecify
# %s: k��da: j�nosaka viens no: -solid, -mod, -gradient\n
$ #Usage
# %s 2.0: (c) 1997-2000 Brad Hughes\n\n\
  -display <virkne>        displeja savienojums\n\
  -mod <x> <y>             modu�a raksts\n\
  -foreground, -fg <kr�sa> modu�a priek�pl�na kr�sa\n\
  -background, -bg <kr�sa> modu�a fona kr�sa\n\n\
  -gradient <tekst�ra>     gradienta tekst�ra\n\
  -from <kr�sa>            p�rejas s�kuma kr�sa\n\
  -to <kr�sa>              p�rejas beigu kr�sa\n\n\
  -solid <kr�sa>           viendab�ga kr�sa\n\n\
  -help                    par�d�t �o pal�dz�bu un iziet\n

