$set 13 #blackbox

$ #NoManagableScreens
# Blackbox::Blackbox: keine verwaltbaren Bildschirme gefunden, Abbruch\n
$ #MapRequest
# Blackbox::process_event: MapRequest von 0x%lx\n
