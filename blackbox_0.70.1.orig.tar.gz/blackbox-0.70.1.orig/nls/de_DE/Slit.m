$set 7 #Slit

$ #SlitTitle
# Slit
$ #SlitDirection
# Slit Ausrichtung 
$ #SlitPlacement
# Slit Platzierung
